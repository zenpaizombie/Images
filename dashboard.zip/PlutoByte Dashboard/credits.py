from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, CreditTransaction, AFKSession, db
from datetime import datetime, timedelta
import secrets
import string
import requests
import json

credits_bp = Blueprint('credits', __name__)

class LinkvertiseService:
    """
    Service for Linkvertise integration
    """
    
    @staticmethod
    def generate_link(user_id: int, target_url: str) -> str:
        """
        Generate a Linkvertise monetized link
        """
        user = User.query.get(user_id)
        if not user or not user.linkvertise_user_id:
            return None
        
        # This would integrate with actual Linkvertise API
        # For demo purposes, we'll create a mock link
        link_id = secrets.token_urlsafe(16)
        return f"https://link-to.net/{user.linkvertise_user_id}/{link_id}"
    
    @staticmethod
    def verify_click(link_id: str) -> bool:
        """
        Verify if a Linkvertise link was clicked and completed
        This would normally check with Linkvertise API
        """
        # Mock verification - in real implementation, this would call Linkvertise API
        return True

class AFKService:
    """
    Service for AFK (Away From Keyboard) credit earning
    """
    
    @staticmethod
    def start_session(user_id: int) -> str:
        """
        Start an AFK session
        """
        # Check if user already has an active session
        active_session = AFKSession.query.filter_by(
            user_id=user_id, 
            status='active'
        ).first()
        
        if active_session:
            return active_session.session_token
        
        # Create new session
        session_token = secrets.token_urlsafe(32)
        session = AFKSession(
            user_id=user_id,
            session_token=session_token,
            start_time=datetime.utcnow(),
            status='active'
        )
        
        db.session.add(session)
        db.session.commit()
        
        return session_token
    
    @staticmethod
    def validate_session(session_token: str) -> bool:
        """
        Validate an AFK session
        """
        session = AFKSession.query.filter_by(
            session_token=session_token,
            status='active'
        ).first()
        
        if not session:
            return False
        
        # Check if session is not too old (max 2 hours)
        if datetime.utcnow() - session.start_time > timedelta(hours=2):
            session.status = 'invalid'
            db.session.commit()
            return False
        
        return True
    
    @staticmethod
    def end_session(session_token: str) -> int:
        """
        End an AFK session and calculate credits earned
        """
        session = AFKSession.query.filter_by(
            session_token=session_token,
            status='active'
        ).first()
        
        if not session:
            return 0
        
        # Calculate time spent (in minutes)
        time_spent = datetime.utcnow() - session.start_time
        minutes_spent = int(time_spent.total_seconds() / 60)
        
        # Calculate credits (1 credit per 5 minutes, max 120 credits per session)
        credits_earned = min(minutes_spent // 5, 120)
        
        # Update session
        session.end_time = datetime.utcnow()
        session.credits_earned = credits_earned
        session.status = 'completed'
        
        # Add credits to user
        user = User.query.get(session.user_id)
        if user:
            user.credits += credits_earned
            
            # Log transaction
            transaction = CreditTransaction(
                user_id=user.id,
                transaction_type='earn',
                amount=credits_earned,
                source='afk',
                description=f'AFK session: {minutes_spent} minutes'
            )
            db.session.add(transaction)
        
        db.session.commit()
        return credits_earned

@credits_bp.route('/balance', methods=['GET'])
@jwt_required()
def get_credit_balance():
    """
    Get user's current credit balance
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify({
            'credits': user.credits
        }), 200
        
    except Exception as e:
        print(f"Get credit balance error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@credits_bp.route('/transactions', methods=['GET'])
@jwt_required()
def get_credit_transactions():
    """
    Get user's credit transaction history
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        transactions = CreditTransaction.query.filter_by(user_id=user.id)\
            .order_by(CreditTransaction.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'transactions': [t.to_dict() for t in transactions.items],
            'total': transactions.total,
            'pages': transactions.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        print(f"Get transactions error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@credits_bp.route('/earn/linkvertise', methods=['POST'])
@jwt_required()
def generate_linkvertise_link():
    """
    Generate a Linkvertise monetized link
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        if not user.linkvertise_user_id:
            return jsonify({
                'error': 'Linkvertise user ID not configured. Please update your profile.'
            }), 400
        
        data = request.get_json()
        target_url = data.get('target_url', 'https://example.com') if data else 'https://example.com'
        
        # Generate Linkvertise link
        link = LinkvertiseService.generate_link(user.id, target_url)
        
        if not link:
            return jsonify({'error': 'Failed to generate link'}), 500
        
        return jsonify({
            'link': link,
            'message': 'Share this link to earn credits when people click it!'
        }), 200
        
    except Exception as e:
        print(f"Generate Linkvertise link error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@credits_bp.route('/earn/linkvertise/verify', methods=['POST'])
@jwt_required()
def verify_linkvertise_click():
    """
    Verify a Linkvertise click and award credits
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json()
        if not data or 'link_id' not in data:
            return jsonify({'error': 'Link ID required'}), 400
        
        link_id = data['link_id']
        
        # Verify the click
        if LinkvertiseService.verify_click(link_id):
            # Award credits (5-15 credits per click)
            credits_earned = 10
            user.credits += credits_earned
            
            # Log transaction
            transaction = CreditTransaction(
                user_id=user.id,
                transaction_type='earn',
                amount=credits_earned,
                source='linkvertise',
                description=f'Linkvertise click: {link_id}'
            )
            db.session.add(transaction)
            db.session.commit()
            
            return jsonify({
                'message': f'Earned {credits_earned} credits!',
                'credits_earned': credits_earned,
                'total_credits': user.credits
            }), 200
        else:
            return jsonify({'error': 'Click verification failed'}), 400
        
    except Exception as e:
        db.session.rollback()
        print(f"Verify Linkvertise click error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@credits_bp.route('/earn/afk/start', methods=['POST'])
@jwt_required()
def start_afk_session():
    """
    Start an AFK earning session
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        session_token = AFKService.start_session(user.id)
        
        return jsonify({
            'message': 'AFK session started',
            'session_token': session_token,
            'instructions': 'Keep this page open and stay active to earn credits!'
        }), 200
        
    except Exception as e:
        print(f"Start AFK session error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@credits_bp.route('/earn/afk/heartbeat', methods=['POST'])
@jwt_required()
def afk_heartbeat():
    """
    AFK session heartbeat to validate user is still active
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json()
        if not data or 'session_token' not in data:
            return jsonify({'error': 'Session token required'}), 400
        
        session_token = data['session_token']
        
        if AFKService.validate_session(session_token):
            return jsonify({
                'status': 'active',
                'message': 'Session is valid'
            }), 200
        else:
            return jsonify({
                'status': 'invalid',
                'message': 'Session expired or invalid'
            }), 400
        
    except Exception as e:
        print(f"AFK heartbeat error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@credits_bp.route('/earn/afk/end', methods=['POST'])
@jwt_required()
def end_afk_session():
    """
    End an AFK session and calculate credits earned
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json()
        if not data or 'session_token' not in data:
            return jsonify({'error': 'Session token required'}), 400
        
        session_token = data['session_token']
        credits_earned = AFKService.end_session(session_token)
        
        # Refresh user data
        db.session.refresh(user)
        
        return jsonify({
            'message': f'AFK session ended. Earned {credits_earned} credits!',
            'credits_earned': credits_earned,
            'total_credits': user.credits
        }), 200
        
    except Exception as e:
        print(f"End AFK session error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@credits_bp.route('/earn/afk/status', methods=['GET'])
@jwt_required()
def get_afk_status():
    """
    Get current AFK session status
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        active_session = AFKSession.query.filter_by(
            user_id=user.id,
            status='active'
        ).first()
        
        if active_session:
            time_elapsed = datetime.utcnow() - active_session.start_time
            minutes_elapsed = int(time_elapsed.total_seconds() / 60)
            potential_credits = min(minutes_elapsed // 5, 120)
            
            return jsonify({
                'has_active_session': True,
                'session_token': active_session.session_token,
                'start_time': active_session.start_time.isoformat(),
                'minutes_elapsed': minutes_elapsed,
                'potential_credits': potential_credits
            }), 200
        else:
            return jsonify({
                'has_active_session': False
            }), 200
        
    except Exception as e:
        print(f"Get AFK status error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

