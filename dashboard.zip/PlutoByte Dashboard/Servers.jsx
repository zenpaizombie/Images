import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useAuth } from '../contexts/AuthContext'
import {
  Server,
  Plus,
  Trash2,
  RefreshCw,
  Clock,
  HardDrive,
  Cpu,
  MemoryStick,
  Play,
  Square,
} from 'lucide-react'

const Servers = () => {
  const [servers, setServers] = useState([])
  const [templates, setTemplates] = useState([])
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  
  const [createForm, setCreateForm] = useState({
    server_name: '',
    template_id: '',
    memory_mb: 1024,
    disk_mb: 2048,
    cpu_percent: 100,
  })

  const { user, getServers, createServer, deleteServer, renewServer, getGameTemplates } = useAuth()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    const [serversResult, templatesResult] = await Promise.all([
      getServers(),
      getGameTemplates()
    ])
    
    if (serversResult.success) {
      setServers(serversResult.servers)
    }
    
    if (templatesResult.success) {
      setTemplates(templatesResult.templates)
    }
    
    setLoading(false)
  }

  const handleCreateServer = async (e) => {
    e.preventDefault()
    setError('')
    setCreating(true)

    const result = await createServer(createForm)

    if (result.success) {
      setSuccess('Server created successfully!')
      setShowCreateDialog(false)
      setCreateForm({
        server_name: '',
        template_id: '',
        memory_mb: 1024,
        disk_mb: 2048,
        cpu_percent: 100,
      })
      loadData()
    } else {
      setError(result.error)
    }

    setCreating(false)
  }

  const handleDeleteServer = async (serverId) => {
    if (!confirm('Are you sure you want to delete this server? This action cannot be undone.')) {
      return
    }

    const result = await deleteServer(serverId)
    if (result.success) {
      setSuccess('Server deleted successfully!')
      loadData()
    } else {
      setError(result.error)
    }
  }

  const handleRenewServer = async (serverId, days) => {
    const result = await renewServer(serverId, days)
    if (result.success) {
      setSuccess(`Server renewed for ${days} days!`)
      loadData()
    } else {
      setError(result.error)
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'online':
        return <Badge className="bg-accent/20 text-accent border-accent">Online</Badge>
      case 'offline':
        return <Badge className="bg-destructive/20 text-destructive border-destructive">Offline</Badge>
      case 'starting':
        return <Badge className="bg-chart-4/20 text-chart-4 border-chart-4">Starting</Badge>
      case 'installing':
        return <Badge className="bg-chart-2/20 text-chart-2 border-chart-2">Installing</Badge>
      default:
        return <Badge className="bg-muted text-muted-foreground">Unknown</Badge>
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'Never'
    return new Date(dateString).toLocaleDateString()
  }

  const calculateCost = () => {
    const template = templates.find(t => t.id === parseInt(createForm.template_id))
    if (!template) return 0

    const baseCost = template.credit_cost_per_day
    const memoryCost = Math.max(0, (createForm.memory_mb - template.default_memory) / 512) * 10
    const diskCost = Math.max(0, (createForm.disk_mb - template.default_disk) / 1024) * 5
    const cpuCost = Math.max(0, (createForm.cpu_percent - template.default_cpu) / 50) * 15

    return Math.max(baseCost, baseCost + memoryCost + diskCost + cpuCost) * 7 // Weekly cost
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Game Servers</h1>
          <p className="text-muted-foreground mt-1">
            Manage your game servers • {3 - servers.length} slots remaining
          </p>
        </div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="btn-neon" disabled={servers.length >= 3}>
              <Plus size={16} className="mr-2" />
              Create Server
            </Button>
          </DialogTrigger>
          <DialogContent className="glass border-border max-w-md">
            <DialogHeader>
              <DialogTitle className="text-foreground">Create New Server</DialogTitle>
              <DialogDescription className="text-muted-foreground">
                Configure your new game server
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateServer} className="space-y-4">
              {error && (
                <Alert className="border-destructive">
                  <AlertDescription className="text-destructive">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="server_name" className="text-foreground">Server Name</Label>
                <Input
                  id="server_name"
                  value={createForm.server_name}
                  onChange={(e) => setCreateForm({...createForm, server_name: e.target.value})}
                  className="input-neon bg-input border-border text-foreground"
                  placeholder="My Awesome Server"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="template_id" className="text-foreground">Game Type</Label>
                <Select
                  value={createForm.template_id}
                  onValueChange={(value) => setCreateForm({...createForm, template_id: value})}
                >
                  <SelectTrigger className="input-neon bg-input border-border text-foreground">
                    <SelectValue placeholder="Select a game" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id.toString()}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-foreground flex items-center">
                    <MemoryStick size={14} className="mr-1" />
                    RAM (MB)
                  </Label>
                  <Input
                    type="number"
                    min="512"
                    max="8192"
                    step="512"
                    value={createForm.memory_mb}
                    onChange={(e) => setCreateForm({...createForm, memory_mb: parseInt(e.target.value)})}
                    className="input-neon bg-input border-border text-foreground"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-foreground flex items-center">
                    <HardDrive size={14} className="mr-1" />
                    Disk (MB)
                  </Label>
                  <Input
                    type="number"
                    min="1024"
                    max="20480"
                    step="1024"
                    value={createForm.disk_mb}
                    onChange={(e) => setCreateForm({...createForm, disk_mb: parseInt(e.target.value)})}
                    className="input-neon bg-input border-border text-foreground"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-foreground flex items-center">
                    <Cpu size={14} className="mr-1" />
                    CPU (%)
                  </Label>
                  <Input
                    type="number"
                    min="50"
                    max="400"
                    step="50"
                    value={createForm.cpu_percent}
                    onChange={(e) => setCreateForm({...createForm, cpu_percent: parseInt(e.target.value)})}
                    className="input-neon bg-input border-border text-foreground"
                  />
                </div>
              </div>

              <div className="bg-card/50 p-3 rounded-lg border border-border">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Weekly Cost:</span>
                  <span className="text-lg font-bold text-primary">{calculateCost()} credits</span>
                </div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-sm text-muted-foreground">Your Balance:</span>
                  <span className="text-sm text-foreground">{user?.credits || 0} credits</span>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full btn-neon"
                disabled={creating || calculateCost() > (user?.credits || 0)}
              >
                {creating ? 'Creating...' : `Create Server (${calculateCost()} credits)`}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Success/Error Messages */}
      {success && (
        <Alert className="border-accent">
          <AlertDescription className="text-accent">
            {success}
          </AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert className="border-destructive">
          <AlertDescription className="text-destructive">
            {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Servers List */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      ) : servers.length === 0 ? (
        <Card className="glass border-border">
          <CardContent className="text-center py-12">
            <Server className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-medium text-foreground mb-2">
              No servers yet
            </h3>
            <p className="text-muted-foreground mb-6">
              Create your first game server to get started
            </p>
            <Button
              onClick={() => setShowCreateDialog(true)}
              className="btn-neon"
              disabled={servers.length >= 3}
            >
              <Plus size={16} className="mr-2" />
              Create Your First Server
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {servers.map((server) => (
            <Card key={server.id} className="card-hover glass border-border">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-primary to-secondary flex items-center justify-center">
                      <Server className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div>
                      <CardTitle className="text-foreground">{server.server_name}</CardTitle>
                      <CardDescription className="text-muted-foreground">
                        {server.game_type}
                      </CardDescription>
                    </div>
                  </div>
                  {getStatusBadge(server.status)}
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <MemoryStick className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-foreground">{server.memory_mb}MB RAM</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <HardDrive className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-foreground">{server.disk_mb}MB Disk</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Cpu className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-foreground">{server.cpu_percent}% CPU</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>Expires {formatDate(server.expires_at)}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      onClick={() => handleRenewServer(server.id, 7)}
                      className="btn-neon-secondary"
                      size="sm"
                    >
                      <RefreshCw size={14} className="mr-1" />
                      Renew 7d
                    </Button>
                    <Button
                      onClick={() => handleDeleteServer(server.id)}
                      variant="outline"
                      size="sm"
                      className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

export default Servers

