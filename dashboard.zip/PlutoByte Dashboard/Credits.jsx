import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useAuth } from '../contexts/AuthContext'
import {
  Coins,
  Link,
  Clock,
  Play,
  Square,
  Copy,
  ExternalLink,
  History,
  Zap,
} from 'lucide-react'

const Credits = () => {
  const [transactions, setTransactions] = useState([])
  const [loading, setLoading] = useState(true)
  const [afkSession, setAfkSession] = useState(null)
  const [afkTime, setAfkTime] = useState(0)
  const [linkvertiseUrl, setLinkvertiseUrl] = useState('')
  const [generatedLink, setGeneratedLink] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const {
    user,
    getCreditTransactions,
    generateLinkvertiseLink,
    startAFKSession,
    endAFKSession,
    afkHeartbeat,
    getAFKStatus,
  } = useAuth()

  useEffect(() => {
    loadData()
    checkAFKStatus()
  }, [])

  useEffect(() => {
    let interval
    if (afkSession) {
      interval = setInterval(() => {
        setAfkTime(prev => prev + 1)
        // Send heartbeat every 30 seconds
        if (afkTime % 30 === 0) {
          sendHeartbeat()
        }
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [afkSession, afkTime])

  const loadData = async () => {
    setLoading(true)
    const result = await getCreditTransactions()
    if (result.success) {
      setTransactions(result.transactions)
    }
    setLoading(false)
  }

  const checkAFKStatus = async () => {
    const result = await getAFKStatus()
    if (result.success && result.has_active_session) {
      setAfkSession({
        token: result.session_token,
        startTime: new Date(result.start_time),
      })
      setAfkTime(result.minutes_elapsed * 60)
    }
  }

  const sendHeartbeat = async () => {
    if (afkSession) {
      const result = await afkHeartbeat(afkSession.token)
      if (!result.success) {
        setAfkSession(null)
        setAfkTime(0)
        setError('AFK session expired')
      }
    }
  }

  const handleGenerateLink = async (e) => {
    e.preventDefault()
    setError('')
    
    const result = await generateLinkvertiseLink(linkvertiseUrl || 'https://example.com')
    if (result.success) {
      setGeneratedLink(result.link)
      setSuccess('Link generated successfully!')
    } else {
      setError(result.error)
    }
  }

  const handleStartAFK = async () => {
    setError('')
    const result = await startAFKSession()
    if (result.success) {
      setAfkSession({
        token: result.sessionToken,
        startTime: new Date(),
      })
      setAfkTime(0)
      setSuccess('AFK session started! Keep this page open to earn credits.')
    } else {
      setError(result.error)
    }
  }

  const handleEndAFK = async () => {
    if (afkSession) {
      const result = await endAFKSession(afkSession.token)
      if (result.success) {
        setAfkSession(null)
        setAfkTime(0)
        setSuccess(`AFK session ended! You earned ${result.creditsEarned} credits.`)
        loadData() // Refresh transactions
      } else {
        setError(result.error)
      }
    }
  }

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
    setSuccess('Link copied to clipboard!')
  }

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString()
  }

  const getTransactionIcon = (source) => {
    switch (source) {
      case 'linkvertise':
        return <Link className="h-4 w-4" />
      case 'afk':
        return <Clock className="h-4 w-4" />
      default:
        return <Coins className="h-4 w-4" />
    }
  }

  const potentialCredits = Math.min(Math.floor(afkTime / 300), 120) // 1 credit per 5 minutes, max 120

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Earn Credits</h1>
          <p className="text-muted-foreground mt-1">
            Earn credits to extend your servers and create new ones
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Current Balance</p>
          <p className="credit-display text-2xl">{user?.credits || 0}</p>
        </div>
      </div>

      {/* Success/Error Messages */}
      {success && (
        <Alert className="border-accent">
          <AlertDescription className="text-accent">
            {success}
          </AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert className="border-destructive">
          <AlertDescription className="text-destructive">
            {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Earning Methods */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Linkvertise */}
        <Card className="card-hover glass border-border">
          <CardHeader>
            <CardTitle className="flex items-center text-foreground">
              <Link className="h-5 w-5 mr-2 text-primary" />
              Linkvertise Links
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Generate monetized links and earn 10 credits per click
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleGenerateLink} className="space-y-3">
              <div className="space-y-2">
                <Label htmlFor="linkvertise_url" className="text-foreground">
                  Target URL (optional)
                </Label>
                <Input
                  id="linkvertise_url"
                  value={linkvertiseUrl}
                  onChange={(e) => setLinkvertiseUrl(e.target.value)}
                  className="input-neon bg-input border-border text-foreground"
                  placeholder="https://example.com"
                />
              </div>
              <Button type="submit" className="w-full btn-neon">
                <Zap size={16} className="mr-2" />
                Generate Link
              </Button>
            </form>

            {generatedLink && (
              <div className="space-y-2">
                <Label className="text-foreground">Generated Link</Label>
                <div className="flex space-x-2">
                  <Input
                    value={generatedLink}
                    readOnly
                    className="bg-input border-border text-foreground"
                  />
                  <Button
                    onClick={() => copyToClipboard(generatedLink)}
                    className="btn-neon-secondary"
                  >
                    <Copy size={16} />
                  </Button>
                  <Button
                    onClick={() => window.open(generatedLink, '_blank')}
                    className="btn-neon-secondary"
                  >
                    <ExternalLink size={16} />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Share this link to earn 10 credits per completed view
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* AFK System */}
        <Card className="card-hover glass border-border">
          <CardHeader>
            <CardTitle className="flex items-center text-foreground">
              <Clock className="h-5 w-5 mr-2 text-secondary" />
              AFK Earning
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Stay active on this page to earn 1 credit per 5 minutes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {afkSession ? (
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">
                    {formatTime(afkTime)}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Session active • {potentialCredits} credits earned
                  </p>
                </div>
                
                <div className="progress-neon h-2">
                  <div 
                    className="progress-fill"
                    style={{ width: `${Math.min((afkTime % 300) / 300 * 100, 100)}%` }}
                  />
                </div>
                
                <Button
                  onClick={handleEndAFK}
                  className="w-full btn-neon-secondary"
                >
                  <Square size={16} className="mr-2" />
                  End Session
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="text-center py-4">
                  <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">
                    Start an AFK session to earn credits passively
                  </p>
                </div>
                
                <Button
                  onClick={handleStartAFK}
                  className="w-full btn-neon"
                >
                  <Play size={16} className="mr-2" />
                  Start AFK Session
                </Button>
              </div>
            )}

            <div className="text-xs text-muted-foreground space-y-1">
              <p>• Earn 1 credit every 5 minutes</p>
              <p>• Maximum 120 credits per session</p>
              <p>• Keep this page open and active</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Transaction History */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center text-foreground">
            <History className="h-5 w-5 mr-2 text-accent" />
            Transaction History
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            Your recent credit transactions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : transactions.length === 0 ? (
            <div className="text-center py-8">
              <Coins className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                No transactions yet
              </h3>
              <p className="text-muted-foreground">
                Start earning credits to see your transaction history
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between p-3 rounded-lg border border-border bg-card/50"
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      transaction.transaction_type === 'earn' 
                        ? 'bg-accent/20 text-accent' 
                        : 'bg-destructive/20 text-destructive'
                    }`}>
                      {getTransactionIcon(transaction.source)}
                    </div>
                    <div>
                      <p className="font-medium text-foreground">
                        {transaction.description}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {formatDate(transaction.created_at)}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${
                      transaction.transaction_type === 'earn' 
                        ? 'text-accent' 
                        : 'text-destructive'
                    }`}>
                      {transaction.transaction_type === 'earn' ? '+' : '-'}{transaction.amount}
                    </p>
                    <Badge variant="outline" className="text-xs">
                      {transaction.source}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default Credits

