from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, Server, GameTemplate, db
from src.pterodactyl_service import PterodactylService
from datetime import datetime, timedelta

server_bp = Blueprint('server', __name__)

@server_bp.route('/templates', methods=['GET'])
@jwt_required()
def get_game_templates():
    """
    Get available game templates
    """
    try:
        pterodactyl_service = PterodactylService()
        templates = pterodactyl_service.get_available_games()
        
        return jsonify({
            'templates': templates
        }), 200
        
    except Exception as e:
        print(f"Get templates error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@server_bp.route('/nodes', methods=['GET'])
@jwt_required()
def get_available_nodes():
    """
    Get available nodes
    """
    try:
        pterodactyl_service = PterodactylService()
        
        if not pterodactyl_service.is_configured():
            return jsonify({'error': 'Pterodactyl not configured'}), 503
        
        nodes = pterodactyl_service.get_available_nodes()
        
        return jsonify({
            'nodes': nodes
        }), 200
        
    except Exception as e:
        print(f"Get nodes error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@server_bp.route('/', methods=['GET'])
@jwt_required()
def get_user_servers():
    """
    Get current user's servers
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        servers = Server.query.filter_by(user_id=user.id).all()
        server_list = []
        
        pterodactyl_service = PterodactylService()
        
        for server in servers:
            server_data = server.to_dict()
            
            # Get real-time status from Pterodactyl if configured
            if pterodactyl_service.is_configured():
                status_info = pterodactyl_service.get_server_status(server)
                server_data.update(status_info)
            
            server_list.append(server_data)
        
        return jsonify({
            'servers': server_list
        }), 200
        
    except Exception as e:
        print(f"Get servers error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@server_bp.route('/', methods=['POST'])
@jwt_required()
def create_server():
    """
    Create a new server
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        server_name = data.get('server_name', '').strip()
        template_id = data.get('template_id')
        memory_mb = data.get('memory_mb')
        disk_mb = data.get('disk_mb')
        cpu_percent = data.get('cpu_percent')
        
        if not all([server_name, template_id, memory_mb, disk_mb, cpu_percent]):
            return jsonify({'error': 'All fields are required'}), 400
        
        # Validate server name
        if len(server_name) < 3 or len(server_name) > 100:
            return jsonify({'error': 'Server name must be between 3 and 100 characters'}), 400
        
        # Get game template
        template = GameTemplate.query.get(template_id)
        if not template or not template.is_active:
            return jsonify({'error': 'Invalid game template'}), 400
        
        # Validate resource limits
        try:
            memory_mb = int(memory_mb)
            disk_mb = int(disk_mb)
            cpu_percent = int(cpu_percent)
        except ValueError:
            return jsonify({'error': 'Invalid resource values'}), 400
        
        if memory_mb < 512 or memory_mb > 8192:
            return jsonify({'error': 'Memory must be between 512MB and 8192MB'}), 400
        
        if disk_mb < 1024 or disk_mb > 20480:
            return jsonify({'error': 'Disk must be between 1024MB and 20480MB'}), 400
        
        if cpu_percent < 50 or cpu_percent > 400:
            return jsonify({'error': 'CPU must be between 50% and 400%'}), 400
        
        # Calculate credit cost (simplified calculation)
        daily_cost = template.credit_cost_per_day
        memory_cost = (memory_mb - template.default_memory) // 512 * 10
        disk_cost = (disk_mb - template.default_disk) // 1024 * 5
        cpu_cost = (cpu_percent - template.default_cpu) // 50 * 15
        
        total_daily_cost = max(daily_cost + memory_cost + disk_cost + cpu_cost, daily_cost)
        weekly_cost = total_daily_cost * 7
        
        # Check if user has enough credits
        if user.credits < weekly_cost:
            return jsonify({
                'error': f'Insufficient credits. Required: {weekly_cost}, Available: {user.credits}'
            }), 400
        
        # Check server limit (max 3 servers per user for free tier)
        existing_servers = Server.query.filter_by(user_id=user.id).count()
        if existing_servers >= 3:
            return jsonify({'error': 'Maximum server limit reached (3 servers)'}), 400
        
        # Create server
        pterodactyl_service = PterodactylService()
        if not pterodactyl_service.is_configured():
            return jsonify({'error': 'Pterodactyl not configured'}), 503
        
        server = pterodactyl_service.create_server(
            user=user,
            server_name=server_name,
            game_template=template,
            memory_mb=memory_mb,
            disk_mb=disk_mb,
            cpu_percent=cpu_percent
        )
        
        if not server:
            return jsonify({'error': 'Failed to create server'}), 500
        
        # Deduct credits
        user.credits -= weekly_cost
        db.session.commit()
        
        # Log credit transaction
        from src.models.user import CreditTransaction
        transaction = CreditTransaction(
            user_id=user.id,
            transaction_type='spend',
            amount=weekly_cost,
            source='server_creation',
            description=f'Created server: {server_name}'
        )
        db.session.add(transaction)
        db.session.commit()
        
        return jsonify({
            'message': 'Server created successfully',
            'server': server.to_dict(),
            'credits_spent': weekly_cost,
            'remaining_credits': user.credits
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Create server error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@server_bp.route('/<int:server_id>', methods=['GET'])
@jwt_required()
def get_server(server_id):
    """
    Get server details
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        server = Server.query.filter_by(id=server_id, user_id=user.id).first()
        if not server:
            return jsonify({'error': 'Server not found'}), 404
        
        server_data = server.to_dict()
        
        # Get real-time status from Pterodactyl
        pterodactyl_service = PterodactylService()
        if pterodactyl_service.is_configured():
            status_info = pterodactyl_service.get_server_status(server)
            server_data.update(status_info)
        
        return jsonify({
            'server': server_data
        }), 200
        
    except Exception as e:
        print(f"Get server error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@server_bp.route('/<int:server_id>', methods=['DELETE'])
@jwt_required()
def delete_server(server_id):
    """
    Delete a server
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        server = Server.query.filter_by(id=server_id, user_id=user.id).first()
        if not server:
            return jsonify({'error': 'Server not found'}), 404
        
        # Delete server
        pterodactyl_service = PterodactylService()
        success = pterodactyl_service.delete_server(server)
        
        if success:
            return jsonify({
                'message': 'Server deleted successfully'
            }), 200
        else:
            return jsonify({'error': 'Failed to delete server'}), 500
        
    except Exception as e:
        print(f"Delete server error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@server_bp.route('/<int:server_id>/renew', methods=['POST'])
@jwt_required()
def renew_server(server_id):
    """
    Renew server for additional time
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        server = Server.query.filter_by(id=server_id, user_id=user.id).first()
        if not server:
            return jsonify({'error': 'Server not found'}), 404
        
        data = request.get_json()
        days = data.get('days', 7) if data else 7
        
        # Validate days
        if days not in [1, 7, 30]:
            return jsonify({'error': 'Invalid renewal period. Choose 1, 7, or 30 days'}), 400
        
        # Get template for cost calculation
        template = GameTemplate.query.filter_by(name=server.game_type).first()
        if not template:
            return jsonify({'error': 'Server template not found'}), 404
        
        # Calculate cost
        daily_cost = template.credit_cost_per_day
        total_cost = daily_cost * days
        
        # Check credits
        if user.credits < total_cost:
            return jsonify({
                'error': f'Insufficient credits. Required: {total_cost}, Available: {user.credits}'
            }), 400
        
        # Extend expiration
        if server.expires_at and server.expires_at > datetime.utcnow():
            # Extend from current expiration
            server.expires_at += timedelta(days=days)
        else:
            # Extend from now
            server.expires_at = datetime.utcnow() + timedelta(days=days)
        
        # Deduct credits
        user.credits -= total_cost
        
        # Log transaction
        from src.models.user import CreditTransaction
        transaction = CreditTransaction(
            user_id=user.id,
            transaction_type='spend',
            amount=total_cost,
            source='server_renewal',
            description=f'Renewed server: {server.server_name} for {days} days'
        )
        db.session.add(transaction)
        db.session.commit()
        
        return jsonify({
            'message': f'Server renewed for {days} days',
            'expires_at': server.expires_at.isoformat(),
            'credits_spent': total_cost,
            'remaining_credits': user.credits
        }), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Renew server error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@server_bp.route('/<int:server_id>/suspend', methods=['POST'])
@jwt_required()
def suspend_server(server_id):
    """
    Suspend a server
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        server = Server.query.filter_by(id=server_id, user_id=user.id).first()
        if not server:
            return jsonify({'error': 'Server not found'}), 404
        
        pterodactyl_service = PterodactylService()
        success = pterodactyl_service.suspend_server(server)
        
        if success:
            return jsonify({
                'message': 'Server suspended successfully'
            }), 200
        else:
            return jsonify({'error': 'Failed to suspend server'}), 500
        
    except Exception as e:
        print(f"Suspend server error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@server_bp.route('/<int:server_id>/unsuspend', methods=['POST'])
@jwt_required()
def unsuspend_server(server_id):
    """
    Unsuspend a server
    """
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        server = Server.query.filter_by(id=server_id, user_id=user.id).first()
        if not server:
            return jsonify({'error': 'Server not found'}), 404
        
        pterodactyl_service = PterodactylService()
        success = pterodactyl_service.unsuspend_server(server)
        
        if success:
            return jsonify({
                'message': 'Server unsuspended successfully'
            }), 200
        else:
            return jsonify({'error': 'Failed to unsuspend server'}), 500
        
    except Exception as e:
        print(f"Unsuspend server error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

