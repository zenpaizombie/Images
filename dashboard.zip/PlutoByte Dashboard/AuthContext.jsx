import { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext()

const API_BASE_URL = 'http://localhost:5000/api'

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [token, setToken] = useState(localStorage.getItem('token'))

  // API helper function
  const apiCall = async (endpoint, options = {}) => {
    const url = `${API_BASE_URL}${endpoint}`
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
      },
      ...options,
    }

    if (config.body && typeof config.body === 'object') {
      config.body = JSON.stringify(config.body)
    }

    try {
      const response = await fetch(url, config)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'API request failed')
      }

      return data
    } catch (error) {
      console.error('API Error:', error)
      throw error
    }
  }

  // Check if user is authenticated on app load
  useEffect(() => {
    const checkAuth = async () => {
      if (token) {
        try {
          const data = await apiCall('/auth/me')
          setUser(data.user)
        } catch (error) {
          console.error('Auth check failed:', error)
          localStorage.removeItem('token')
          setToken(null)
        }
      }
      setLoading(false)
    }

    checkAuth()
  }, [token])

  const login = async (credentials) => {
    try {
      const data = await apiCall('/auth/login', {
        method: 'POST',
        body: credentials,
      })

      const { access_token, user: userData } = data
      localStorage.setItem('token', access_token)
      setToken(access_token)
      setUser(userData)

      return { success: true }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const register = async (userData) => {
    try {
      const data = await apiCall('/auth/register', {
        method: 'POST',
        body: userData,
      })

      const { access_token, user: newUser } = data
      localStorage.setItem('token', access_token)
      setToken(access_token)
      setUser(newUser)

      return { success: true }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const logout = () => {
    localStorage.removeItem('token')
    setToken(null)
    setUser(null)
  }

  const updateProfile = async (profileData) => {
    try {
      const data = await apiCall('/auth/update-profile', {
        method: 'PUT',
        body: profileData,
      })

      setUser(data.user)
      return { success: true }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const changePassword = async (passwordData) => {
    try {
      await apiCall('/auth/change-password', {
        method: 'PUT',
        body: passwordData,
      })

      return { success: true }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  // Server management functions
  const getServers = async () => {
    try {
      const data = await apiCall('/servers/')
      return { success: true, servers: data.servers }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const createServer = async (serverData) => {
    try {
      const data = await apiCall('/servers/', {
        method: 'POST',
        body: serverData,
      })

      // Update user credits
      if (user) {
        setUser({ ...user, credits: data.remaining_credits })
      }

      return { success: true, server: data.server }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const deleteServer = async (serverId) => {
    try {
      await apiCall(`/servers/${serverId}`, {
        method: 'DELETE',
      })

      return { success: true }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const renewServer = async (serverId, days) => {
    try {
      const data = await apiCall(`/servers/${serverId}/renew`, {
        method: 'POST',
        body: { days },
      })

      // Update user credits
      if (user) {
        setUser({ ...user, credits: data.remaining_credits })
      }

      return { success: true, data }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  // Credit management functions
  const getCreditBalance = async () => {
    try {
      const data = await apiCall('/credits/balance')
      return { success: true, credits: data.credits }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const getCreditTransactions = async (page = 1) => {
    try {
      const data = await apiCall(`/credits/transactions?page=${page}`)
      return { success: true, ...data }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const generateLinkvertiseLink = async (targetUrl) => {
    try {
      const data = await apiCall('/credits/earn/linkvertise', {
        method: 'POST',
        body: { target_url: targetUrl },
      })

      return { success: true, link: data.link }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const startAFKSession = async () => {
    try {
      const data = await apiCall('/credits/earn/afk/start', {
        method: 'POST',
      })

      return { success: true, sessionToken: data.session_token }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const endAFKSession = async (sessionToken) => {
    try {
      const data = await apiCall('/credits/earn/afk/end', {
        method: 'POST',
        body: { session_token: sessionToken },
      })

      // Update user credits
      if (user) {
        setUser({ ...user, credits: data.total_credits })
      }

      return { success: true, creditsEarned: data.credits_earned }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const afkHeartbeat = async (sessionToken) => {
    try {
      const data = await apiCall('/credits/earn/afk/heartbeat', {
        method: 'POST',
        body: { session_token: sessionToken },
      })

      return { success: true, status: data.status }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const getAFKStatus = async () => {
    try {
      const data = await apiCall('/credits/earn/afk/status')
      return { success: true, ...data }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const getGameTemplates = async () => {
    try {
      const data = await apiCall('/servers/templates')
      return { success: true, templates: data.templates }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }

  const value = {
    user,
    loading,
    login,
    register,
    logout,
    updateProfile,
    changePassword,
    getServers,
    createServer,
    deleteServer,
    renewServer,
    getCreditBalance,
    getCreditTransactions,
    generateLinkvertiseLink,
    startAFKSession,
    endAFKSession,
    afkHeartbeat,
    getAFKStatus,
    getGameTemplates,
    apiCall,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

