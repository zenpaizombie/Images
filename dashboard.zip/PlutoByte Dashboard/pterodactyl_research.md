# Pterodactyl Panel API Research

## Overview
Pterodactyl Panel is a free, open-source game server management panel built with PHP, React, and Go. It provides both Client API and Application API endpoints.

## API Types
1. **Client API** (`/api/client`) - For end users to manage their servers
2. **Application API** (`/api/application`) - For administrators to manage users, servers, nodes, etc.

## Authentication
- Client API Key: Generated from `https://pterodactyl.app/account/api`
- Application API Key: Generated from `https://pterodactyl.app/admin/api`
- API keys are used as Bearer tokens in Authorization header
- Accept header: `Application/vnd.pterodactyl.v1+json`

## Rate Limits
- 240 requests per minute
- Headers returned: `x-ratelimit-limit` and `x-ratelimit-remaining`

## Key Features Found
- List servers endpoint
- Server management capabilities
- User permissions system
- File management
- Backup management
- Allocation management

## Next Steps
- Find Application API endpoints for:
  - Creating users
  - Creating servers
  - Managing nodes
  - Resource allocation



## User Creation API
**Endpoint**: POST `/api/application/users`
**Required Parameters**:
- email: Email address (unique)
- username: Username (required, between 1-255 chars, unique)
- password: Password (required)
- language: Language (required, string)
- root_admin: Whether root admin or not (boolean)
- first_name: First name (required, between 1-255 chars)
- last_name: Last name (required, between 1-255 chars)

**Optional Parameters**:
- external_id: External ID (nullable, max 255 chars, unique)

**Response**: Returns user instance with ID, UUID, username, email, etc.

## Server Creation API
**Endpoint**: POST `/api/application/servers`
**Required Parameters**:
- name: Server name (required, min 1, max 255 chars)
- user: Server owner's user ID (required, integer, must exist)
- egg: Egg ID (required, must exist)
- docker_image: Docker image (required, max 255 chars)
- startup: Startup command (required)
- limits: Resource limits (required array)
  - memory: Memory limit (required, numeric, min 0)
  - swap: Swap limit (required, numeric, min -1)
  - disk: Disk limit (required, numeric, min 0)
  - io: IO limit (required, numeric, between 10-1000)
  - cpu: CPU limit (required, numeric, min 0)
- feature_limits: Feature limits (required array)
  - databases: Database limit (nullable, integer, min 0)
  - allocations: Allocation limit (nullable, integer, min 0)
- deploy: Deploy information (required array)
  - locations: Deploy locations (array)
  - dedicated_ip: Use dedicated IP or not (boolean)
  - port_range: Port ranges (array)

**Optional Parameters**:
- external_id: External ID (nullable, between 1-191 chars, unique)
- description: Description (nullable)
- pack: Pack ID (nullable, numeric, min 0)
- environment: Environment variables (array)
- allocation: Allocation IDs (array)
- start_on_completion: Start server after installation (boolean)
- skip_scripts: Skip egg scripts (boolean)
- oom_disabled: Disable OOM killer (boolean)

## Key Concepts
- **Nodes**: Physical servers that host game servers
- **Locations**: Geographical locations where nodes are located
- **Nests**: Categories of game types (e.g., Minecraft, Source Games)
- **Eggs**: Specific game configurations within nests (e.g., Vanilla Minecraft, Spigot)
- **Allocations**: IP:Port combinations assigned to servers

