# Pterodactyl Client Dashboard - Design System

## Design Philosophy
The dashboard embraces a **cyberpunk-inspired aesthetic** with a black base and vibrant neon accents. The design should feel modern, gaming-oriented, and professional while maintaining excellent usability and accessibility.

## Color Palette

### Primary Colors
- **Background Black**: `#0a0a0a` - Main background
- **Surface Black**: `#1a1a1a` - Card backgrounds, panels
- **Border Dark**: `#2a2a2a` - Subtle borders and dividers

### Neon Accent Colors
- **Neon Cyan**: `#00ffff` - Primary accent, buttons, links
- **Neon Purple**: `#bf00ff` - Secondary accent, highlights
- **Neon Green**: `#00ff41` - Success states, online indicators
- **Neon Orange**: `#ff6600` - Warning states, pending actions
- **Neon Red**: `#ff0040` - Error states, danger actions

### Text Colors
- **Primary Text**: `#ffffff` - Main text, headings
- **Secondary Text**: `#b3b3b3` - Subtext, descriptions
- **Muted Text**: `#666666` - Disabled text, placeholders

### Utility Colors
- **Glass Effect**: `rgba(255, 255, 255, 0.1)` - Glassmorphism overlays
- **Glow Effect**: `rgba(0, 255, 255, 0.3)` - Neon glow shadows
- **Gradient Primary**: `linear-gradient(135deg, #00ffff, #bf00ff)`
- **Gradient Secondary**: `linear-gradient(135deg, #ff6600, #ff0040)`

## Typography

### Font Stack
- **Primary**: `'Inter', 'Segoe UI', system-ui, sans-serif`
- **Monospace**: `'JetBrains Mono', 'Fira Code', monospace` (for server IDs, code)

### Font Sizes
- **Display**: `3rem` (48px) - Hero headings
- **H1**: `2.5rem` (40px) - Page titles
- **H2**: `2rem` (32px) - Section headings
- **H3**: `1.5rem` (24px) - Subsection headings
- **Body**: `1rem` (16px) - Regular text
- **Small**: `0.875rem` (14px) - Captions, metadata
- **Tiny**: `0.75rem` (12px) - Labels, badges

### Font Weights
- **Light**: 300
- **Regular**: 400
- **Medium**: 500
- **Semibold**: 600
- **Bold**: 700

## Layout System

### Grid System
- **Container Max Width**: `1400px`
- **Breakpoints**:
  - Mobile: `320px - 768px`
  - Tablet: `768px - 1024px`
  - Desktop: `1024px+`

### Spacing Scale (rem)
- **xs**: `0.25rem` (4px)
- **sm**: `0.5rem` (8px)
- **md**: `1rem` (16px)
- **lg**: `1.5rem` (24px)
- **xl**: `2rem` (32px)
- **2xl**: `3rem` (48px)
- **3xl**: `4rem` (64px)

### Border Radius
- **Small**: `4px` - Buttons, inputs
- **Medium**: `8px` - Cards, panels
- **Large**: `12px` - Modals, major components
- **Round**: `50%` - Avatars, circular buttons

## Component Design Principles

### Cards & Panels
- **Background**: Surface black with subtle border
- **Border**: 1px solid border dark color
- **Shadow**: Subtle glow effect for depth
- **Padding**: 24px for content areas

### Buttons
- **Primary**: Neon cyan background with white text
- **Secondary**: Transparent with neon cyan border
- **Danger**: Neon red background with white text
- **Ghost**: Transparent with text color only
- **Hover Effects**: Increase glow intensity, slight scale

### Form Elements
- **Inputs**: Dark background with neon border on focus
- **Labels**: Secondary text color, small font size
- **Validation**: Neon green for success, neon red for errors

### Navigation
- **Sidebar**: Fixed left navigation with dark background
- **Active States**: Neon accent with glow effect
- **Icons**: Consistent sizing, neon colors for active states

## Visual Effects

### Glassmorphism
- **Background**: `rgba(255, 255, 255, 0.1)`
- **Backdrop Filter**: `blur(10px)`
- **Border**: `1px solid rgba(255, 255, 255, 0.2)`

### Neon Glow Effects
```css
.neon-glow {
  box-shadow: 
    0 0 5px currentColor,
    0 0 10px currentColor,
    0 0 15px currentColor,
    0 0 20px currentColor;
}
```

### Animations
- **Hover Transitions**: `0.2s ease-in-out`
- **Page Transitions**: `0.3s ease-in-out`
- **Loading Animations**: Pulsing neon effects
- **Micro-interactions**: Subtle scale and glow changes

## Iconography
- **Style**: Outline icons with consistent stroke width
- **Size**: 16px, 20px, 24px standard sizes
- **Color**: Inherit from parent or neon accents
- **Source**: Heroicons, Lucide, or custom SVGs

## Dashboard Layout Structure

### Header
- Logo/brand on the left
- User info and credits on the right
- Height: 64px
- Background: Surface black with bottom border

### Sidebar Navigation
- Width: 280px (desktop), collapsible on mobile
- Sections: Dashboard, Servers, Earn Credits, Account
- Active state with neon accent and glow

### Main Content Area
- Responsive grid layout
- Card-based components
- Proper spacing and hierarchy

### Server Cards
- Server name and status prominently displayed
- Resource usage with progress bars
- Action buttons (start, stop, restart, delete)
- Neon status indicators (green=online, orange=starting, red=offline)

### Credit Earning Pages
- Clear call-to-action buttons
- Progress tracking with neon progress bars
- Gamified elements with achievements

## Accessibility Considerations
- **Contrast Ratios**: Ensure WCAG AA compliance
- **Focus States**: Clear focus indicators with neon outlines
- **Screen Readers**: Proper ARIA labels and semantic HTML
- **Keyboard Navigation**: Full keyboard accessibility
- **Motion**: Respect prefers-reduced-motion settings

## Responsive Design
- **Mobile-first approach**
- **Collapsible sidebar** on smaller screens
- **Stacked layouts** for mobile
- **Touch-friendly** button sizes (44px minimum)
- **Readable text** at all screen sizes

## Brand Elements
- **Logo**: Stylized pterodactyl with neon accents
- **Favicon**: Simplified pterodactyl icon
- **Loading States**: Animated pterodactyl or neon pulse
- **Empty States**: Friendly illustrations with neon styling

