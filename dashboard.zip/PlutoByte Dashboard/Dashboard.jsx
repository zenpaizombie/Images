import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '../contexts/AuthContext'
import {
  Server,
  Coins,
  Plus,
  Activity,
  Clock,
  Zap,
} from 'lucide-react'

const Dashboard = () => {
  const [servers, setServers] = useState([])
  const [loading, setLoading] = useState(true)
  const { user, getServers } = useAuth()

  useEffect(() => {
    loadServers()
  }, [])

  const loadServers = async () => {
    setLoading(true)
    const result = await getServers()
    if (result.success) {
      setServers(result.servers)
    }
    setLoading(false)
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'online':
        return 'status-online'
      case 'offline':
        return 'status-offline'
      case 'starting':
        return 'status-starting'
      default:
        return 'text-muted-foreground'
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'online':
        return <Badge className="bg-accent/20 text-accent border-accent">Online</Badge>
      case 'offline':
        return <Badge className="bg-destructive/20 text-destructive border-destructive">Offline</Badge>
      case 'starting':
        return <Badge className="bg-chart-4/20 text-chart-4 border-chart-4">Starting</Badge>
      default:
        return <Badge className="bg-muted text-muted-foreground">Unknown</Badge>
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'Never'
    return new Date(dateString).toLocaleDateString()
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            Welcome back, {user?.username}!
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage your game servers and earn credits
          </p>
        </div>
        <div className="credit-display">
          {user?.credits || 0}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="card-hover glass border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-foreground">
              Active Servers
            </CardTitle>
            <Server className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {servers.filter(s => s.status === 'online').length}
            </div>
            <p className="text-xs text-muted-foreground">
              of {servers.length} total servers
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover glass border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-foreground">
              Credits Balance
            </CardTitle>
            <Coins className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {user?.credits || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              <Link to="/credits" className="text-primary hover:underline">
                Earn more credits
              </Link>
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover glass border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-foreground">
              Server Slots
            </CardTitle>
            <Activity className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {3 - servers.length}
            </div>
            <p className="text-xs text-muted-foreground">
              slots remaining
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Servers */}
      <Card className="glass border-border">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-foreground">Your Servers</CardTitle>
            <CardDescription className="text-muted-foreground">
              Manage your game servers
            </CardDescription>
          </div>
          <Link to="/servers">
            <Button className="btn-neon">
              <Plus size={16} className="mr-2" />
              Create Server
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : servers.length === 0 ? (
            <div className="text-center py-8">
              <Server className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                No servers yet
              </h3>
              <p className="text-muted-foreground mb-4">
                Create your first game server to get started
              </p>
              <Link to="/servers">
                <Button className="btn-neon">
                  <Plus size={16} className="mr-2" />
                  Create Your First Server
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {servers.slice(0, 3).map((server) => (
                <div
                  key={server.id}
                  className="flex items-center justify-between p-4 rounded-lg border border-border bg-card/50"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-primary to-secondary flex items-center justify-center">
                      <Server className="h-5 w-5 text-primary-foreground" />
                    </div>
                    <div>
                      <h4 className="font-medium text-foreground">
                        {server.server_name}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {server.game_type} • {server.memory_mb}MB RAM
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">
                          Expires {formatDate(server.expires_at)}
                        </span>
                      </div>
                    </div>
                    {getStatusBadge(server.status)}
                  </div>
                </div>
              ))}
              {servers.length > 3 && (
                <div className="text-center pt-4">
                  <Link to="/servers">
                    <Button variant="outline" className="btn-neon-secondary">
                      View All Servers
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="card-hover glass border-border">
          <CardHeader>
            <CardTitle className="flex items-center text-foreground">
              <Zap className="h-5 w-5 mr-2 text-primary" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link to="/servers" className="block">
              <Button className="w-full btn-neon-secondary justify-start">
                <Plus size={16} className="mr-2" />
                Create New Server
              </Button>
            </Link>
            <Link to="/credits" className="block">
              <Button className="w-full btn-neon-secondary justify-start">
                <Coins size={16} className="mr-2" />
                Earn Credits
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="card-hover glass border-border">
          <CardHeader>
            <CardTitle className="text-foreground">Getting Started</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <div className="flex items-start space-x-2">
              <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0"></div>
              <p>Create your first game server with your free credits</p>
            </div>
            <div className="flex items-start space-x-2">
              <div className="w-2 h-2 rounded-full bg-secondary mt-2 flex-shrink-0"></div>
              <p>Earn more credits through our reward system</p>
            </div>
            <div className="flex items-start space-x-2">
              <div className="w-2 h-2 rounded-full bg-accent mt-2 flex-shrink-0"></div>
              <p>Invite friends and get bonus credits</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Dashboard

