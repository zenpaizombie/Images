# Pterodactyl Dashboard Configuration

## Backend Configuration (Flask)

### Environment Variables
Create a `.env` file in the backend directory with the following variables:

```env
# Flask Configuration
FLASK_ENV=development
SECRET_KEY=your-secret-key-here
JWT_SECRET_KEY=your-jwt-secret-key-here

# Database Configuration
DATABASE_URL=sqlite:///pterodactyl_dashboard.db

# Pterodactyl Panel Configuration
PTERODACTYL_URL=https://your-pterodactyl-panel.com
PTERODACTYL_API_KEY=your-pterodactyl-api-key
PTERODACTYL_NODE_ID=1

# Credit System Configuration
LINKVERTISE_API_KEY=your-linkvertise-api-key
DEFAULT_CREDITS=1000
CREDITS_PER_AFK_MINUTE=0.2
MAX_AFK_CREDITS_PER_SESSION=120

# Server Configuration
MAX_SERVERS_PER_USER=3
DEFAULT_SERVER_MEMORY=1024
DEFAULT_SERVER_DISK=2048
DEFAULT_SERVER_CPU=100
```

### Game Templates Configuration
The system supports the following game templates:

1. **Minecraft Java Edition**
   - Memory: 1024MB - 8192MB
   - Disk: 2048MB - 20480MB
   - CPU: 100% - 400%
   - Cost: 50 credits/week base

2. **Minecraft Bedrock Edition**
   - Memory: 512MB - 4096MB
   - Disk: 1024MB - 10240MB
   - CPU: 50% - 200%
   - Cost: 30 credits/week base

3. **Discord Bot**
   - Memory: 256MB - 1024MB
   - Disk: 512MB - 2048MB
   - CPU: 25% - 100%
   - Cost: 20 credits/week base

4. **Node.js Application**
   - Memory: 512MB - 2048MB
   - Disk: 1024MB - 5120MB
   - CPU: 50% - 200%
   - Cost: 35 credits/week base

## Frontend Configuration (React)

### Environment Variables
Create a `.env` file in the frontend directory:

```env
VITE_API_BASE_URL=http://localhost:5000/api
VITE_APP_NAME=Pterodactyl Dashboard
```

### Build Configuration
For production builds:

```bash
npm run build
```

## Deployment Instructions

### Backend Deployment (Flask)

1. **Install Dependencies**
   ```bash
   cd pterodactyl_dashboard
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. **Configure Environment**
   - Copy `.env.example` to `.env`
   - Update all configuration values
   - Ensure Pterodactyl API key has admin permissions

3. **Initialize Database**
   ```bash
   python src/main.py
   # Database will be created automatically on first run
   ```

4. **Run Production Server**
   ```bash
   gunicorn --bind 0.0.0.0:5000 src.main:app
   ```

### Frontend Deployment (React)

1. **Install Dependencies**
   ```bash
   cd pterodactyl-dashboard-frontend
   npm install
   ```

2. **Build for Production**
   ```bash
   npm run build
   ```

3. **Deploy Static Files**
   - Upload `dist/` folder to your web server
   - Configure web server to serve React app
   - Ensure API endpoints are accessible

### Docker Deployment (Recommended)

Create `docker-compose.yml`:

```yaml
version: '3.8'
services:
  backend:
    build: ./pterodactyl_dashboard
    ports:
      - "5000:5000"
    environment:
      - FLASK_ENV=production
      - DATABASE_URL=sqlite:///data/pterodactyl_dashboard.db
    volumes:
      - ./data:/app/data
    restart: unless-stopped

  frontend:
    build: ./pterodactyl-dashboard-frontend
    ports:
      - "80:80"
    depends_on:
      - backend
    restart: unless-stopped
```

## Security Considerations

1. **API Keys**
   - Store all API keys in environment variables
   - Never commit API keys to version control
   - Use different keys for development and production

2. **Database Security**
   - Use PostgreSQL or MySQL for production
   - Enable SSL connections
   - Regular backups

3. **Authentication**
   - JWT tokens expire after 24 hours
   - Passwords are hashed using bcrypt
   - Rate limiting on authentication endpoints

4. **CORS Configuration**
   - Configure CORS for production domains only
   - Disable debug mode in production

## Monitoring and Maintenance

1. **Logging**
   - All API requests are logged
   - Error tracking with stack traces
   - Credit transactions are audited

2. **Health Checks**
   - `/api/health` endpoint for monitoring
   - Database connection checks
   - Pterodactyl API connectivity checks

3. **Backup Strategy**
   - Daily database backups
   - User data export functionality
   - Server configuration backups

## Troubleshooting

### Common Issues

1. **Pterodactyl API Connection Failed**
   - Check API key permissions
   - Verify Pterodactyl URL is correct
   - Ensure firewall allows connections

2. **Frontend Not Loading**
   - Check CORS configuration
   - Verify API base URL in frontend
   - Check browser console for errors

3. **Credit System Not Working**
   - Verify Linkvertise API key
   - Check AFK session timeouts
   - Review credit transaction logs

### Support

For technical support:
- Check application logs
- Review configuration files
- Test API endpoints manually
- Verify Pterodactyl panel connectivity

