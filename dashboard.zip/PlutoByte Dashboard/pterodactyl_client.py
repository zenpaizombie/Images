import requests
import json
from typing import Dict, List, Optional, Any

class PterodactylAPIClient:
    """
    Client for interacting with Pterodactyl Panel API
    """
    
    def __init__(self, panel_url: str, api_key: str):
        self.panel_url = panel_url.rstrip('/')
        self.api_key = api_key
        self.headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
            'Accept': 'Application/vnd.pterodactyl.v1+json'
        }
    
    def _make_request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict:
        """
        Make HTTP request to Pterodactyl API
        """
        url = f"{self.panel_url}/api/application{endpoint}"
        
        try:
            if method.upper() == 'GET':
                response = requests.get(url, headers=self.headers)
            elif method.upper() == 'POST':
                response = requests.post(url, headers=self.headers, json=data)
            elif method.upper() == 'PUT':
                response = requests.put(url, headers=self.headers, json=data)
            elif method.upper() == 'DELETE':
                response = requests.delete(url, headers=self.headers)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            
            if response.content:
                return response.json()
            else:
                return {}
                
        except requests.exceptions.RequestException as e:
            raise Exception(f"API request failed: {str(e)}")
    
    # User Management
    def create_user(self, email: str, username: str, first_name: str, last_name: str, password: str, external_id: Optional[str] = None) -> Dict:
        """
        Create a new user in Pterodactyl panel
        """
        data = {
            'email': email,
            'username': username,
            'first_name': first_name,
            'last_name': last_name,
            'password': password,
            'language': 'en',
            'root_admin': False
        }
        
        if external_id:
            data['external_id'] = external_id
        
        return self._make_request('POST', '/users', data)
    
    def get_user(self, user_id: int) -> Dict:
        """
        Get user information by ID
        """
        return self._make_request('GET', f'/users/{user_id}')
    
    def get_user_by_external_id(self, external_id: str) -> Dict:
        """
        Get user information by external ID
        """
        return self._make_request('GET', f'/users/external/{external_id}')
    
    def update_user(self, user_id: int, **kwargs) -> Dict:
        """
        Update user information
        """
        return self._make_request('PUT', f'/users/{user_id}', kwargs)
    
    def delete_user(self, user_id: int) -> Dict:
        """
        Delete a user
        """
        return self._make_request('DELETE', f'/users/{user_id}')
    
    # Server Management
    def create_server(self, name: str, user_id: int, egg_id: int, docker_image: str, startup: str, 
                     memory: int, swap: int, disk: int, io: int, cpu: int, 
                     databases: int, allocations: int, locations: List[int],
                     environment: Optional[Dict] = None, external_id: Optional[str] = None,
                     description: str = "", start_on_completion: bool = True) -> Dict:
        """
        Create a new server
        """
        data = {
            'name': name,
            'user': user_id,
            'egg': egg_id,
            'docker_image': docker_image,
            'startup': startup,
            'limits': {
                'memory': memory,
                'swap': swap,
                'disk': disk,
                'io': io,
                'cpu': cpu
            },
            'feature_limits': {
                'databases': databases,
                'allocations': allocations
            },
            'deploy': {
                'locations': locations,
                'dedicated_ip': False,
                'port_range': []
            },
            'environment': environment or {},
            'description': description,
            'start_on_completion': start_on_completion,
            'skip_scripts': False,
            'oom_disabled': False
        }
        
        if external_id:
            data['external_id'] = external_id
        
        return self._make_request('POST', '/servers', data)
    
    def get_server(self, server_id: int) -> Dict:
        """
        Get server information by ID
        """
        return self._make_request('GET', f'/servers/{server_id}')
    
    def get_servers(self, page: int = 1) -> Dict:
        """
        Get list of servers
        """
        return self._make_request('GET', f'/servers?page={page}')
    
    def update_server_details(self, server_id: int, name: str, user_id: int, external_id: Optional[str] = None, description: str = "") -> Dict:
        """
        Update server details
        """
        data = {
            'name': name,
            'user': user_id,
            'description': description
        }
        
        if external_id:
            data['external_id'] = external_id
        
        return self._make_request('PUT', f'/servers/{server_id}/details', data)
    
    def update_server_build(self, server_id: int, memory: int, swap: int, disk: int, io: int, cpu: int, 
                           databases: int, allocations: int, allocation_id: int) -> Dict:
        """
        Update server build configuration
        """
        data = {
            'allocation': allocation_id,
            'limits': {
                'memory': memory,
                'swap': swap,
                'disk': disk,
                'io': io,
                'cpu': cpu
            },
            'feature_limits': {
                'databases': databases,
                'allocations': allocations
            }
        }
        
        return self._make_request('PUT', f'/servers/{server_id}/build', data)
    
    def suspend_server(self, server_id: int) -> Dict:
        """
        Suspend a server
        """
        return self._make_request('POST', f'/servers/{server_id}/suspend')
    
    def unsuspend_server(self, server_id: int) -> Dict:
        """
        Unsuspend a server
        """
        return self._make_request('POST', f'/servers/{server_id}/unsuspend')
    
    def delete_server(self, server_id: int, force: bool = False) -> Dict:
        """
        Delete a server
        """
        endpoint = f'/servers/{server_id}/force' if force else f'/servers/{server_id}'
        return self._make_request('DELETE', endpoint)
    
    # Node Management
    def get_nodes(self) -> Dict:
        """
        Get list of nodes
        """
        return self._make_request('GET', '/nodes')
    
    def get_node(self, node_id: int) -> Dict:
        """
        Get node information by ID
        """
        return self._make_request('GET', f'/nodes/{node_id}')
    
    def get_node_allocations(self, node_id: int) -> Dict:
        """
        Get allocations for a specific node
        """
        return self._make_request('GET', f'/nodes/{node_id}/allocations')
    
    # Location Management
    def get_locations(self) -> Dict:
        """
        Get list of locations
        """
        return self._make_request('GET', '/locations')
    
    def get_location(self, location_id: int) -> Dict:
        """
        Get location information by ID
        """
        return self._make_request('GET', f'/locations/{location_id}')
    
    # Nest and Egg Management
    def get_nests(self) -> Dict:
        """
        Get list of nests
        """
        return self._make_request('GET', '/nests')
    
    def get_nest(self, nest_id: int) -> Dict:
        """
        Get nest information by ID
        """
        return self._make_request('GET', f'/nests/{nest_id}')
    
    def get_nest_eggs(self, nest_id: int) -> Dict:
        """
        Get eggs for a specific nest
        """
        return self._make_request('GET', f'/nests/{nest_id}/eggs')
    
    def get_egg(self, nest_id: int, egg_id: int) -> Dict:
        """
        Get egg information by ID
        """
        return self._make_request('GET', f'/nests/{nest_id}/eggs/{egg_id}')
    
    # Allocation Management
    def get_allocations(self) -> Dict:
        """
        Get list of allocations
        """
        return self._make_request('GET', '/allocations')
    
    def create_allocation(self, node_id: int, ip: str, ports: List[str], alias: Optional[str] = None) -> Dict:
        """
        Create new allocations
        """
        data = {
            'ip': ip,
            'ports': ports
        }
        
        if alias:
            data['alias'] = alias
        
        return self._make_request('POST', f'/nodes/{node_id}/allocations', data)
    
    def delete_allocation(self, node_id: int, allocation_id: int) -> Dict:
        """
        Delete an allocation
        """
        return self._make_request('DELETE', f'/nodes/{node_id}/allocations/{allocation_id}')

