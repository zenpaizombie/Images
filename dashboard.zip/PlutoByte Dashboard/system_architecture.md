# System Architecture & Database Schema

## Overall System Architecture

### Components
1. **Frontend Dashboard** (React)
   - User authentication interface
   - Server management dashboard
   - Credit earning pages
   - Account management

2. **Backend API** (Flask)
   - User authentication & session management
   - Pterodactyl API integration
   - Credit earning system
   - Database operations

3. **Database** (SQLite/PostgreSQL)
   - User accounts
   - Server records
   - Credit transactions
   - AFK sessions

4. **External Integrations**
   - Pterodactyl Panel API
   - Linkvertise API
   - URL shortening services

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    pterodactyl_user_id INTEGER,
    credits INTEGER DEFAULT 0,
    linkvertise_user_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Servers Table
```sql
CREATE TABLE servers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    pterodactyl_server_id INTEGER,
    server_name VARCHAR(100) NOT NULL,
    game_type VARCHAR(50) NOT NULL,
    node_id INTEGER NOT NULL,
    memory_mb INTEGER NOT NULL,
    disk_mb INTEGER NOT NULL,
    cpu_percent INTEGER NOT NULL,
    status VARCHAR(20) DEFAULT 'creating',
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### Credit_Transactions Table
```sql
CREATE TABLE credit_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    transaction_type VARCHAR(20) NOT NULL, -- 'earn', 'spend'
    amount INTEGER NOT NULL,
    source VARCHAR(50) NOT NULL, -- 'linkvertise', 'afk', 'server_renewal'
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### AFK_Sessions Table
```sql
CREATE TABLE afk_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    session_token VARCHAR(255) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    credits_earned INTEGER DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'completed', 'invalid'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### Pterodactyl_Config Table
```sql
CREATE TABLE pterodactyl_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    panel_url VARCHAR(255) NOT NULL,
    api_key VARCHAR(255) NOT NULL,
    default_node_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Game_Templates Table
```sql
CREATE TABLE game_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    egg_id INTEGER NOT NULL,
    nest_id INTEGER NOT NULL,
    docker_image VARCHAR(255) NOT NULL,
    startup_command TEXT NOT NULL,
    default_memory INTEGER NOT NULL,
    default_disk INTEGER NOT NULL,
    default_cpu INTEGER NOT NULL,
    credit_cost_per_day INTEGER NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user info

### Server Management
- `GET /api/servers` - List user's servers
- `POST /api/servers` - Create new server
- `GET /api/servers/{id}` - Get server details
- `DELETE /api/servers/{id}` - Delete server
- `POST /api/servers/{id}/renew` - Renew server with credits

### Credit System
- `GET /api/credits/balance` - Get user's credit balance
- `GET /api/credits/transactions` - Get transaction history
- `POST /api/credits/earn/linkvertise` - Generate Linkvertise link
- `POST /api/credits/earn/afk/start` - Start AFK session
- `POST /api/credits/earn/afk/end` - End AFK session

### Game Templates
- `GET /api/templates` - List available game templates

### Admin (if needed)
- `GET /api/admin/users` - List all users
- `GET /api/admin/servers` - List all servers
- `POST /api/admin/config` - Update Pterodactyl config

## Security Considerations
1. **Authentication**: JWT tokens for session management
2. **Rate Limiting**: Prevent abuse of credit earning systems
3. **Input Validation**: Sanitize all user inputs
4. **API Key Security**: Encrypt Pterodactyl API keys in database
5. **AFK Anti-Cheat**: Multiple validation methods for AFK sessions

