import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '../contexts/AuthContext'
import {
  User,
  Mail,
  Key,
  Settings,
  ExternalLink,
  Save,
  Shield,
} from 'lucide-react'

const Profile = () => {
  const { user, updateProfile, changePassword } = useAuth()
  
  const [profileForm, setProfileForm] = useState({
    email: user?.email || '',
    linkvertise_user_id: user?.linkvertise_user_id || '',
  })
  
  const [passwordForm, setPasswordForm] = useState({
    current_password: '',
    new_password: '',
    confirm_password: '',
  })
  
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const handleProfileSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    const result = await updateProfile(profileForm)

    if (result.success) {
      setSuccess('Profile updated successfully!')
    } else {
      setError(result.error)
    }

    setLoading(false)
  }

  const handlePasswordSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (passwordForm.new_password !== passwordForm.confirm_password) {
      setError('New passwords do not match')
      return
    }

    if (passwordForm.new_password.length < 8) {
      setError('New password must be at least 8 characters long')
      return
    }

    setLoading(true)

    const result = await changePassword({
      current_password: passwordForm.current_password,
      new_password: passwordForm.new_password,
    })

    if (result.success) {
      setSuccess('Password changed successfully!')
      setPasswordForm({
        current_password: '',
        new_password: '',
        confirm_password: '',
      })
    } else {
      setError(result.error)
    }

    setLoading(false)
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'Unknown'
    return new Date(dateString).toLocaleDateString()
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Profile Settings</h1>
          <p className="text-muted-foreground mt-1">
            Manage your account settings and preferences
          </p>
        </div>
      </div>

      {/* Success/Error Messages */}
      {success && (
        <Alert className="border-accent">
          <AlertDescription className="text-accent">
            {success}
          </AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert className="border-destructive">
          <AlertDescription className="text-destructive">
            {error}
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Account Information */}
        <Card className="glass border-border">
          <CardHeader>
            <CardTitle className="flex items-center text-foreground">
              <User className="h-5 w-5 mr-2 text-primary" />
              Account Information
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              View and update your account details
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-foreground">Username</Label>
              <Input
                value={user?.username || ''}
                readOnly
                className="bg-muted border-border text-muted-foreground"
              />
              <p className="text-xs text-muted-foreground">
                Username cannot be changed
              </p>
            </div>

            <form onSubmit={handleProfileSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-foreground">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={profileForm.email}
                  onChange={(e) => setProfileForm({...profileForm, email: e.target.value})}
                  className="input-neon bg-input border-border text-foreground"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="linkvertise_user_id" className="text-foreground">
                  Linkvertise User ID
                </Label>
                <Input
                  id="linkvertise_user_id"
                  type="number"
                  value={profileForm.linkvertise_user_id}
                  onChange={(e) => setProfileForm({...profileForm, linkvertise_user_id: e.target.value})}
                  className="input-neon bg-input border-border text-foreground"
                  placeholder="Enter your Linkvertise user ID"
                />
                <p className="text-xs text-muted-foreground">
                  Required to generate monetized links.{' '}
                  <a
                    href="https://linkvertise.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline inline-flex items-center"
                  >
                    Get your ID here <ExternalLink size={12} className="ml-1" />
                  </a>
                </p>
              </div>

              <Button
                type="submit"
                className="w-full btn-neon"
                disabled={loading}
              >
                <Save size={16} className="mr-2" />
                {loading ? 'Saving...' : 'Save Changes'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Account Stats */}
        <Card className="glass border-border">
          <CardHeader>
            <CardTitle className="flex items-center text-foreground">
              <Settings className="h-5 w-5 mr-2 text-secondary" />
              Account Statistics
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Your account overview and status
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 rounded-lg bg-card/50 border border-border">
                <div className="text-2xl font-bold text-primary">
                  {user?.credits || 0}
                </div>
                <p className="text-sm text-muted-foreground">Credits</p>
              </div>
              
              <div className="text-center p-3 rounded-lg bg-card/50 border border-border">
                <div className="text-2xl font-bold text-secondary">
                  {user?.pterodactyl_user_id ? '✓' : '✗'}
                </div>
                <p className="text-sm text-muted-foreground">Pterodactyl</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Member since:</span>
                <span className="text-sm text-foreground">{formatDate(user?.created_at)}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Last updated:</span>
                <span className="text-sm text-foreground">{formatDate(user?.updated_at)}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Account status:</span>
                <Badge className="bg-accent/20 text-accent border-accent">Active</Badge>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Linkvertise setup:</span>
                {user?.linkvertise_user_id ? (
                  <Badge className="bg-accent/20 text-accent border-accent">Configured</Badge>
                ) : (
                  <Badge className="bg-chart-4/20 text-chart-4 border-chart-4">Not configured</Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card className="glass border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center text-foreground">
              <Shield className="h-5 w-5 mr-2 text-accent" />
              Security Settings
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Change your password and manage security settings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePasswordSubmit} className="space-y-4 max-w-md">
              <div className="space-y-2">
                <Label htmlFor="current_password" className="text-foreground">
                  Current Password
                </Label>
                <Input
                  id="current_password"
                  type="password"
                  value={passwordForm.current_password}
                  onChange={(e) => setPasswordForm({...passwordForm, current_password: e.target.value})}
                  className="input-neon bg-input border-border text-foreground"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="new_password" className="text-foreground">
                  New Password
                </Label>
                <Input
                  id="new_password"
                  type="password"
                  value={passwordForm.new_password}
                  onChange={(e) => setPasswordForm({...passwordForm, new_password: e.target.value})}
                  className="input-neon bg-input border-border text-foreground"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm_password" className="text-foreground">
                  Confirm New Password
                </Label>
                <Input
                  id="confirm_password"
                  type="password"
                  value={passwordForm.confirm_password}
                  onChange={(e) => setPasswordForm({...passwordForm, confirm_password: e.target.value})}
                  className="input-neon bg-input border-border text-foreground"
                  required
                />
              </div>

              <Button
                type="submit"
                className="btn-neon"
                disabled={loading}
              >
                <Key size={16} className="mr-2" />
                {loading ? 'Changing...' : 'Change Password'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Profile

