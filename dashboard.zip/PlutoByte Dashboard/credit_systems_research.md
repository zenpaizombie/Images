# Credit Earning Systems Research

## Linkvertise API
Linkvertise is a URL shortening service that allows users to monetize their links by displaying ads before redirecting to the original URL.

### JavaScript API
```javascript
linkvertise(userid, link)
// Example: linkvertise(65354, "https://google.com")
// Returns: https://link-to.net/65354/941.870834/...
```

### Python API
```python
from linkvertise import LinkvertiseClient

# Define the client
client = LinkvertiseClient()

# Create a linkvertise URL
# 25565 is your linkvertise account id
link = client.linkvertise(25565, "google.com")
print(link)
# Returns: https://link-to.net/25565/832.365248384998/...
```

### How it works:
1. User creates a Linkvertise account and gets a user ID
2. API generates monetized links that show ads before redirecting
3. User earns money when people click through the ads
4. Revenue is shared between Linkvertise and the user

## URL Shortening Monetization Services
Popular services include:
- **ShrinkEarn**: High-paying URL shortener
- **SafelinkU**: Earn money per click
- **AdLinkFly**: Self-hosted monetized URL shortener script
- **Linkvertise**: German-focused, high-paying service

### Common Features:
- Pay per click/view
- Geographic targeting for higher rates
- Analytics and tracking
- API integration
- Referral programs

## AFK (Away From Keyboard) System
An AFK system typically works by:
1. User stays on a page for a specified duration
2. System tracks time spent actively on the page
3. Credits are awarded based on time spent
4. Anti-cheat measures prevent automation

### Implementation Considerations:
- Page visibility detection
- Mouse movement/activity tracking
- Periodic check-ins to verify presence
- Rate limiting to prevent abuse
- Session management

## Integration Strategy for Dashboard
1. **Linkvertise Integration**:
   - Store user's Linkvertise account ID
   - Generate monetized links for earning tasks
   - Track clicks and earnings

2. **Alternative URL Shortener** (if "Linkpays" is different):
   - Research and implement similar API
   - Same concept: monetized links for earning

3. **AFK System**:
   - JavaScript-based activity tracking
   - Server-side session validation
   - Credit calculation based on time
   - Anti-cheat mechanisms

4. **Credit Management**:
   - Database to track user credits
   - Conversion rates (time/clicks to credits)
   - Credit spending for server renewals
   - Transaction history

