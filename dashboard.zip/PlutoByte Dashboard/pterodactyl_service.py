from typing import Dict, List, Optional
from src.pterodactyl_client import PterodactylAPIClient
from src.models.user import User, Server, GameTemplate, PterodactylConfig, db
from datetime import datetime, timedelta
import secrets
import string

class PterodactylService:
    """
    Service layer for Pterodactyl integration
    """
    
    def __init__(self):
        self.client = None
        self._load_config()
    
    def _load_config(self):
        """
        Load Pterodactyl configuration from database
        """
        config = PterodactylConfig.query.first()
        if config:
            self.client = PterodactylAPIClient(config.panel_url, config.api_key)
            self.default_node_id = config.default_node_id
        else:
            self.client = None
            self.default_node_id = None
    
    def is_configured(self) -> bool:
        """
        Check if Pterodactyl is properly configured
        """
        return self.client is not None
    
    def configure(self, panel_url: str, api_key: str, default_node_id: int) -> bool:
        """
        Configure Pterodactyl connection
        """
        try:
            # Test the connection
            test_client = PterodactylAPIClient(panel_url, api_key)
            test_client.get_nodes()  # Test API call
            
            # Save configuration
            config = PterodactylConfig.query.first()
            if config:
                config.panel_url = panel_url
                config.api_key = api_key
                config.default_node_id = default_node_id
            else:
                config = PterodactylConfig(
                    panel_url=panel_url,
                    api_key=api_key,
                    default_node_id=default_node_id
                )
                db.session.add(config)
            
            db.session.commit()
            self._load_config()
            return True
            
        except Exception as e:
            print(f"Failed to configure Pterodactyl: {str(e)}")
            return False
    
    def create_pterodactyl_user(self, user: User) -> bool:
        """
        Create a user in Pterodactyl panel
        """
        if not self.is_configured():
            raise Exception("Pterodactyl not configured")
        
        try:
            # Generate a random password for Pterodactyl
            password = self._generate_password()
            
            # Create user in Pterodactyl
            response = self.client.create_user(
                email=user.email,
                username=user.username,
                first_name=user.username,
                last_name="User",
                password=password,
                external_id=str(user.id)
            )
            
            # Update user with Pterodactyl ID
            user.pterodactyl_user_id = response['attributes']['id']
            db.session.commit()
            
            return True
            
        except Exception as e:
            print(f"Failed to create Pterodactyl user: {str(e)}")
            return False
    
    def create_server(self, user: User, server_name: str, game_template: GameTemplate, 
                     memory_mb: int, disk_mb: int, cpu_percent: int) -> Optional[Server]:
        """
        Create a server in Pterodactyl and database
        """
        if not self.is_configured():
            raise Exception("Pterodactyl not configured")
        
        if not user.pterodactyl_user_id:
            if not self.create_pterodactyl_user(user):
                raise Exception("Failed to create Pterodactyl user")
        
        try:
            # Create server in database first
            server = Server(
                user_id=user.id,
                server_name=server_name,
                game_type=game_template.name,
                node_id=self.default_node_id,
                memory_mb=memory_mb,
                disk_mb=disk_mb,
                cpu_percent=cpu_percent,
                status='creating',
                expires_at=datetime.utcnow() + timedelta(days=7)  # Default 7 days
            )
            db.session.add(server)
            db.session.flush()  # Get the server ID
            
            # Create server in Pterodactyl
            response = self.client.create_server(
                name=server_name,
                user_id=user.pterodactyl_user_id,
                egg_id=game_template.egg_id,
                docker_image=game_template.docker_image,
                startup=game_template.startup_command,
                memory=memory_mb,
                swap=0,
                disk=disk_mb,
                io=500,
                cpu=cpu_percent,
                databases=1,
                allocations=1,
                locations=[self.default_node_id],
                external_id=str(server.id),
                description=f"Server created via dashboard for {user.username}",
                start_on_completion=True
            )
            
            # Update server with Pterodactyl ID
            server.pterodactyl_server_id = response['attributes']['id']
            server.status = 'installing'
            db.session.commit()
            
            return server
            
        except Exception as e:
            db.session.rollback()
            print(f"Failed to create server: {str(e)}")
            return None
    
    def get_server_status(self, server: Server) -> Dict:
        """
        Get server status from Pterodactyl
        """
        if not self.is_configured() or not server.pterodactyl_server_id:
            return {'status': 'unknown'}
        
        try:
            response = self.client.get_server(server.pterodactyl_server_id)
            return {
                'status': 'online' if not response['attributes']['suspended'] else 'suspended',
                'suspended': response['attributes']['suspended'],
                'installing': response['attributes'].get('is_installing', False)
            }
        except Exception as e:
            print(f"Failed to get server status: {str(e)}")
            return {'status': 'error'}
    
    def delete_server(self, server: Server) -> bool:
        """
        Delete server from Pterodactyl and database
        """
        if not self.is_configured():
            return False
        
        try:
            # Delete from Pterodactyl if it exists
            if server.pterodactyl_server_id:
                self.client.delete_server(server.pterodactyl_server_id, force=True)
            
            # Delete from database
            db.session.delete(server)
            db.session.commit()
            
            return True
            
        except Exception as e:
            print(f"Failed to delete server: {str(e)}")
            return False
    
    def suspend_server(self, server: Server) -> bool:
        """
        Suspend server in Pterodactyl
        """
        if not self.is_configured() or not server.pterodactyl_server_id:
            return False
        
        try:
            self.client.suspend_server(server.pterodactyl_server_id)
            server.status = 'suspended'
            db.session.commit()
            return True
        except Exception as e:
            print(f"Failed to suspend server: {str(e)}")
            return False
    
    def unsuspend_server(self, server: Server) -> bool:
        """
        Unsuspend server in Pterodactyl
        """
        if not self.is_configured() or not server.pterodactyl_server_id:
            return False
        
        try:
            self.client.unsuspend_server(server.pterodactyl_server_id)
            server.status = 'online'
            db.session.commit()
            return True
        except Exception as e:
            print(f"Failed to unsuspend server: {str(e)}")
            return False
    
    def get_available_nodes(self) -> List[Dict]:
        """
        Get list of available nodes
        """
        if not self.is_configured():
            return []
        
        try:
            response = self.client.get_nodes()
            return [
                {
                    'id': node['attributes']['id'],
                    'name': node['attributes']['name'],
                    'location_id': node['attributes']['location_id'],
                    'public': node['attributes']['public']
                }
                for node in response['data']
            ]
        except Exception as e:
            print(f"Failed to get nodes: {str(e)}")
            return []
    
    def get_available_games(self) -> List[Dict]:
        """
        Get list of available game templates from database
        """
        templates = GameTemplate.query.filter_by(is_active=True).all()
        return [template.to_dict() for template in templates]
    
    def seed_game_templates(self):
        """
        Seed the database with common game templates
        """
        templates = [
            {
                'name': 'Minecraft Java',
                'description': 'Vanilla Minecraft Java Edition server',
                'egg_id': 1,  # These would need to be configured based on your Pterodactyl setup
                'nest_id': 1,
                'docker_image': 'ghcr.io/pterodactyl/yolks:java_17',
                'startup_command': 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
                'default_memory': 1024,
                'default_disk': 2048,
                'default_cpu': 100,
                'credit_cost_per_day': 50
            },
            {
                'name': 'CS:GO',
                'description': 'Counter-Strike: Global Offensive server',
                'egg_id': 2,
                'nest_id': 2,
                'docker_image': 'ghcr.io/pterodactyl/games:source',
                'startup_command': './srcds_run -game csgo -console -usercon +game_type 0 +game_mode 1 +mapgroup mg_active +map de_dust2',
                'default_memory': 2048,
                'default_disk': 4096,
                'default_cpu': 150,
                'credit_cost_per_day': 75
            },
            {
                'name': 'ARK: Survival Evolved',
                'description': 'ARK: Survival Evolved dedicated server',
                'egg_id': 3,
                'nest_id': 3,
                'docker_image': 'ghcr.io/pterodactyl/games:ark',
                'startup_command': './ShooterGameServer TheIsland?listen?SessionName={{SESSION_NAME}}?ServerPassword={{ARK_PASSWORD}}?ServerAdminPassword={{ARK_ADMIN_PASSWORD}}?Port={{SERVER_PORT}}?QueryPort={{QUERY_PORT}}?MaxPlayers={{MAX_PLAYERS}}',
                'default_memory': 4096,
                'default_disk': 8192,
                'default_cpu': 200,
                'credit_cost_per_day': 100
            },
            {
                'name': 'Rust',
                'description': 'Rust dedicated server',
                'egg_id': 4,
                'nest_id': 4,
                'docker_image': 'ghcr.io/pterodactyl/games:rust',
                'startup_command': './RustDedicated -batchmode +server.port {{SERVER_PORT}} +server.identity "rust" +rcon.port {{RCON_PORT}} +rcon.web true +server.hostname "{{HOSTNAME}}" +server.level "{{LEVEL}}" +server.description "{{DESCRIPTION}}" +server.url "{{SERVER_URL}}" +server.headerimage "{{SERVER_IMG}}" +server.logoimage "{{SERVER_LOGO}}" +server.maxplayers {{MAX_PLAYERS}} +rcon.password "{{RCON_PASS}}" +server.saveinterval {{SAVEINTERVAL}} +app.port {{APP_PORT}} {{ADDITIONAL_ARGS}}',
                'default_memory': 3072,
                'default_disk': 6144,
                'default_cpu': 175,
                'credit_cost_per_day': 85
            }
        ]
        
        for template_data in templates:
            existing = GameTemplate.query.filter_by(name=template_data['name']).first()
            if not existing:
                template = GameTemplate(**template_data)
                db.session.add(template)
        
        db.session.commit()
    
    def _generate_password(self, length: int = 12) -> str:
        """
        Generate a random password
        """
        alphabet = string.ascii_letters + string.digits
        return ''.join(secrets.choice(alphabet) for _ in range(length))

