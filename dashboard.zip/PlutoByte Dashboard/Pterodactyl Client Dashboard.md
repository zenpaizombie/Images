# Pterodactyl Client Dashboard

A comprehensive web dashboard for managing free game servers on Pterodactyl Panel with an integrated credit earning system.

![Dashboard Preview](https://private-us-east-1.manuscdn.com/sessionFile/zwZai6sKaSfSd5ERC8jhuR/sandbox/r45hfpLVTqlVXz1TK7svjb-images_1750644352203_na1fn_L2hvbWUvdWJ1bnR1L2Rlc2lnbl9tb2NrdXBzL2Rhc2hib2FyZF9tYWlu.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvendaYWk2c0thU2ZTZDVFUkM4amh1Ui9zYW5kYm94L3I0NWhmcExWVHFsVlh6MVRLN3N2amItaW1hZ2VzXzE3NTA2NDQzNTIyMDNfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyUmxjMmxuYmw5dGIyTnJkWEJ6TDJSaGMyaGliMkZ5WkY5dFlXbHUucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzY3MjI1NjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=eZdStUIh3Gu0VfhwtvncaXJKhwJe8Ef1xJAA-yg~jAROZB-bl5EN5r1yEtayWYIYoxU1Y5a0DS4mn-9bDatC~GiRlXLlAuSbovUSqz0DhGhMIFJU61yKw5bGHHL2Ja3PaE7WU531i1ltuz3ERgjkyGC5erVWoHD6EfdDqXgy5tFUhy8asE-cOavFc0O6h8vu6pncGtLBWSNo91fxxj9XIjfb6jQryc9OOHaqQpiFm-N8eOx61j1UJ6vhG2EEeScZ-0QnuOhF0b~AwLSlePLjS65DENOW~bSZfaeSBmGCf1-~xYf4jy4~UrWKhKOI-8Z5amaCLIxetG2NpDaS44rtfg__)

## 🚀 Features

### 🎮 Game Server Management
- **Free Server Creation**: Create up to 3 game servers with your free credits
- **Multiple Game Types**: Support for Minecraft (Java & Bedrock), Discord Bots, Node.js apps
- **Resource Allocation**: Customize RAM, disk space, and CPU allocation
- **Server Lifecycle**: Start, stop, restart, and delete servers
- **Automatic Renewal**: Extend server lifetime using credits

### 💰 Credit Earning System
- **Welcome Bonus**: 1000 free credits on registration
- **Linkvertise Integration**: Generate monetized links to earn credits
- **AFK System**: Earn credits by staying active on the dashboard
- **Transaction History**: Track all credit earnings and spending

### 🎨 Modern UI/UX
- **Cyberpunk Theme**: Black background with neon cyan and purple accents
- **Responsive Design**: Works perfectly on desktop and mobile devices
- **Glassmorphism Effects**: Modern glass-like UI components
- **Smooth Animations**: Hover effects and transitions throughout

### 🔐 Security & Authentication
- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: Bcrypt encryption for user passwords
- **Session Management**: Automatic token refresh and logout
- **Rate Limiting**: Protection against brute force attacks

### 🔗 Pterodactyl Integration
- **Automatic User Creation**: Creates Pterodactyl users automatically
- **Server Provisioning**: Deploys servers on specified nodes
- **Resource Management**: Enforces resource limits and quotas
- **Status Monitoring**: Real-time server status updates

## 📸 Screenshots

### Login Page
![Login](https://private-us-east-1.manuscdn.com/sessionFile/zwZai6sKaSfSd5ERC8jhuR/sandbox/r45hfpLVTqlVXz1TK7svjb-images_1750644352203_na1fn_L2hvbWUvdWJ1bnR1L2Rlc2lnbl9tb2NrdXBzL2Rhc2hib2FyZF9tYWlu.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvendaYWk2c0thU2ZTZDVFUkM4amh1Ui9zYW5kYm94L3I0NWhmcExWVHFsVlh6MVRLN3N2amItaW1hZ2VzXzE3NTA2NDQzNTIyMDNfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyUmxjMmxuYmw5dGIyTnJkWEJ6TDJSaGMyaGliMkZ5WkY5dFlXbHUucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzY3MjI1NjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=eZdStUIh3Gu0VfhwtvncaXJKhwJe8Ef1xJAA-yg~jAROZB-bl5EN5r1yEtayWYIYoxU1Y5a0DS4mn-9bDatC~GiRlXLlAuSbovUSqz0DhGhMIFJU61yKw5bGHHL2Ja3PaE7WU531i1ltuz3ERgjkyGC5erVWoHD6EfdDqXgy5tFUhy8asE-cOavFc0O6h8vu6pncGtLBWSNo91fxxj9XIjfb6jQryc9OOHaqQpiFm-N8eOx61j1UJ6vhG2EEeScZ-0QnuOhF0b~AwLSlePLjS65DENOW~bSZfaeSBmGCf1-~xYf4jy4~UrWKhKOI-8Z5amaCLIxetG2NpDaS44rtfg__)

### Server Management
![Servers](https://private-us-east-1.manuscdn.com/sessionFile/zwZai6sKaSfSd5ERC8jhuR/sandbox/r45hfpLVTqlVXz1TK7svjb-images_1750644352204_na1fn_L2hvbWUvdWJ1bnR1L2Rlc2lnbl9tb2NrdXBzL3NlcnZlcl9tYW5hZ2VtZW50.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvendaYWk2c0thU2ZTZDVFUkM4amh1Ui9zYW5kYm94L3I0NWhmcExWVHFsVlh6MVRLN3N2amItaW1hZ2VzXzE3NTA2NDQzNTIyMDRfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyUmxjMmxuYmw5dGIyTnJkWEJ6TDNObGNuWmxjbDl0WVc1aFoyVnRaVzUwLnBuZyIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc2NzIyNTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=LTzDK0J~UPkoCE-ZiHvEHs1ycBuNWGBdLVf3eD0s8JIy3UpyqLa-eWO~NFHnvX80XSP1Z7S3bcTx-n1~CH51JJMJKoAVwpUSVc74Y45FqMQ0HzNVLQ0vgzvxbYfs2rzDOOy75ll8y173t5SjK9XfbelxDLNvfMwIfAQ32t1PdgH258qUItKr3KXr-JlrrdP5LCYLfpjtNxdIkHeecD5YCSGhLDbmk70wyRFJfSFfpJTh-RoGCTfWEG1RTxUN0IscNSgARQDVxBXIvWnA4Rg4QEw9T60NkdlkVMpWykA4rv4s8xlABsWn9RQ6vYBx0LeT0PR3y41yGbDCk3G5k527EA__)

### Credit Earning
![Credits](https://private-us-east-1.manuscdn.com/sessionFile/zwZai6sKaSfSd5ERC8jhuR/sandbox/r45hfpLVTqlVXz1TK7svjb-images_1750644352204_na1fn_L2hvbWUvdWJ1bnR1L2Rlc2lnbl9tb2NrdXBzL2NyZWRpdF9lYXJuaW5n.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvendaYWk2c0thU2ZTZDVFUkM4amh1Ui9zYW5kYm94L3I0NWhmcExWVHFsVlh6MVRLN3N2amItaW1hZ2VzXzE3NTA2NDQzNTIyMDRfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyUmxjMmxuYmw5dGIyTnJkWEJ6TDJOeVpXUnBkRjlsWVhKdWFXNW4ucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzY3MjI1NjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=CadW67DTCSnI5F8F8fR8zHjdsr5j1Ax-~HQbM8oXEM89Nh3vPrTryvUpAd8yul~6fNfYWCx2YGN4PjXOF2-hurXEapXGnxDgki3fmedPN9bTesEum1FCxNrxS~pkAnsbPSiNAntyLUuMET4CUWsRgksubtzQVK5bmMo476KB0nLJvNMLhzalqQ1INZV6ISc0rXwqw79I1qT4G9~gxD1LTXJoe7tKmwuHPmqImcO7FB3tjT4Ql~gEkxX1tbXURX4mkExHgW5SoIoNU~hKZrYhDltkcHEW4KouCyLlq7FodvEKdHaLR-41PlyO0OTF4W5kgiHOGwm0enRsJAf1v8gENg__)

### Server Creation
![Create Server](https://private-us-east-1.manuscdn.com/sessionFile/zwZai6sKaSfSd5ERC8jhuR/sandbox/r45hfpLVTqlVXz1TK7svjb-images_1750644352205_na1fn_L2hvbWUvdWJ1bnR1L2Rlc2lnbl9tb2NrdXBzL3NlcnZlcl9jcmVhdGlvbg.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvendaYWk2c0thU2ZTZDVFUkM4amh1Ui9zYW5kYm94L3I0NWhmcExWVHFsVlh6MVRLN3N2amItaW1hZ2VzXzE3NTA2NDQzNTIyMDVfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyUmxjMmxuYmw5dGIyTnJkWEJ6TDNObGNuWmxjbDlqY21WaGRHbHZiZy5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3NjcyMjU2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=My2aGgNgXj5m2hm~Bd80QZSlGXqhCwyI7ujW0Mga2gzp9Gb5~c-98pWOOpTQdqe~~XliwICwtsWCkhI~Bp-35R5FpQX7G3RJDyvLIR9OP~hUuL~x1u~GEtwtP0pYHnQNc63yF9kVt7O1sZ2JuFv~2B1Bgx2G-iOy-b-lzs0Q-skyEe5~hAsEC-repWx0Af-H7wNtGH-~XXGnfFW~4KgA~rI7rLVa3dauPQDuQ7d3egWP8okvB~lWHlw8kpU~t6FxAo9eZWk5tA1U5o2JDEC-9YjGfJECIdeSNADF-LPXARMK505bXjNVRfuzkr0ukfcbRHTTTR8sOT5t2LLG3UQ6ag__)

## 🛠️ Technology Stack

### Backend
- **Flask**: Python web framework
- **SQLAlchemy**: Database ORM
- **JWT**: Authentication tokens
- **Requests**: HTTP client for Pterodactyl API
- **Flask-CORS**: Cross-origin resource sharing

### Frontend
- **React**: Modern JavaScript framework
- **Vite**: Fast build tool and dev server
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Beautiful icon library
- **React Router**: Client-side routing

### Database
- **SQLite**: Development database (easily upgradeable to PostgreSQL/MySQL)
- **User Management**: Users, credits, transactions
- **Server Tracking**: Server instances and configurations

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- Node.js 16+
- Pterodactyl Panel with API access
- Linkvertise account (optional)

### Installation

1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd pterodactyl-dashboard
   ```

2. **Backend Setup**
   ```bash
   cd pterodactyl_dashboard
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. **Frontend Setup**
   ```bash
   cd ../pterodactyl-dashboard-frontend
   npm install
   ```

4. **Configuration**
   - Copy `.env.example` to `.env` in both directories
   - Update configuration values (see [Deployment Guide](DEPLOYMENT_GUIDE.md))

5. **Run Development Servers**
   
   Backend:
   ```bash
   cd pterodactyl_dashboard
   source venv/bin/activate
   python src/main.py
   ```
   
   Frontend:
   ```bash
   cd pterodactyl-dashboard-frontend
   npm run dev
   ```

6. **Access the Dashboard**
   - Open http://localhost:5173 in your browser
   - Register a new account to get started

## 📋 Configuration

### Pterodactyl Panel Setup

1. **Create API Key**
   - Go to your Pterodactyl admin panel
   - Navigate to Application API
   - Create a new API key with full permissions

2. **Configure Node**
   - Ensure you have at least one node configured
   - Note the node ID for configuration

3. **Update Environment Variables**
   ```env
   PTERODACTYL_URL=https://your-panel.com
   PTERODACTYL_API_KEY=your-api-key
   PTERODACTYL_NODE_ID=1
   ```

### Credit System Setup

1. **Linkvertise Integration**
   - Sign up at https://linkvertise.com
   - Get your user ID from the dashboard
   - Users can add their Linkvertise ID in their profile

2. **AFK System Configuration**
   ```env
   CREDITS_PER_AFK_MINUTE=0.2
   MAX_AFK_CREDITS_PER_SESSION=120
   ```

## 🎮 Supported Game Types

### Minecraft Java Edition
- **Memory**: 1024MB - 8192MB
- **Disk**: 2048MB - 20480MB
- **CPU**: 100% - 400%
- **Base Cost**: 50 credits/week

### Minecraft Bedrock Edition
- **Memory**: 512MB - 4096MB
- **Disk**: 1024MB - 10240MB
- **CPU**: 50% - 200%
- **Base Cost**: 30 credits/week

### Discord Bot
- **Memory**: 256MB - 1024MB
- **Disk**: 512MB - 2048MB
- **CPU**: 25% - 100%
- **Base Cost**: 20 credits/week

### Node.js Application
- **Memory**: 512MB - 2048MB
- **Disk**: 1024MB - 5120MB
- **CPU**: 50% - 200%
- **Base Cost**: 35 credits/week

## 💡 Usage Guide

### Getting Started

1. **Register Account**
   - Create a new account with username, email, and password
   - Receive 1000 free credits automatically

2. **Create Your First Server**
   - Navigate to the Servers page
   - Click "Create Server"
   - Choose game type and configure resources
   - Pay with credits to deploy

3. **Earn More Credits**
   - Visit the Credits page
   - Generate Linkvertise links for sharing
   - Start AFK sessions to earn passively
   - Monitor your transaction history

4. **Manage Servers**
   - View server status and details
   - Renew servers before expiration
   - Delete servers to free up slots

### Credit Earning Tips

1. **Linkvertise Links**
   - Share links on social media
   - Each completed view earns 10 credits
   - Target URLs can be customized

2. **AFK System**
   - Keep the dashboard open and active
   - Earn 1 credit every 5 minutes
   - Maximum 120 credits per session

3. **Server Management**
   - Delete unused servers to save credits
   - Choose appropriate resource allocations
   - Renew servers in advance for discounts

## 🔧 API Documentation

### Authentication Endpoints
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user
- `PUT /api/auth/update-profile` - Update profile
- `PUT /api/auth/change-password` - Change password

### Server Management
- `GET /api/servers/` - List user servers
- `POST /api/servers/` - Create new server
- `DELETE /api/servers/{id}` - Delete server
- `POST /api/servers/{id}/renew` - Renew server
- `GET /api/servers/templates` - Get game templates

### Credit System
- `GET /api/credits/balance` - Get credit balance
- `GET /api/credits/transactions` - Transaction history
- `POST /api/credits/earn/linkvertise` - Generate Linkvertise link
- `POST /api/credits/earn/afk/start` - Start AFK session
- `POST /api/credits/earn/afk/end` - End AFK session
- `POST /api/credits/earn/afk/heartbeat` - AFK heartbeat

## 🚀 Deployment

For production deployment instructions, see [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md).

### Docker Deployment (Recommended)

```bash
docker-compose up -d
```

### Manual Deployment

1. Build frontend: `npm run build`
2. Configure web server (nginx/apache)
3. Set up reverse proxy for backend
4. Configure SSL certificates
5. Set up monitoring and backups

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

### Common Issues

1. **Server Creation Fails**
   - Check Pterodactyl API key permissions
   - Verify node has available resources
   - Ensure sufficient credits

2. **Credits Not Updating**
   - Check Linkvertise configuration
   - Verify AFK session is active
   - Review transaction logs

3. **Login Issues**
   - Clear browser cache and cookies
   - Check username/password
   - Verify backend is running

### Getting Help

- Check the [Deployment Guide](DEPLOYMENT_GUIDE.md)
- Review application logs
- Test API endpoints manually
- Contact support with error details

## 🎯 Roadmap

### Planned Features

- [ ] Server backups and restoration
- [ ] Custom server templates
- [ ] Team/organization support
- [ ] Advanced monitoring and analytics
- [ ] Mobile app
- [ ] Plugin marketplace
- [ ] Advanced credit earning methods
- [ ] Server scheduling and automation

### Version History

- **v1.0.0** - Initial release with core features
- **v1.1.0** - Enhanced UI and mobile support
- **v1.2.0** - Advanced credit earning system
- **v2.0.0** - Team collaboration features (planned)

---

**Made with ❤️ for the gaming community**

*Empowering gamers to host their own servers without the cost barrier.*

